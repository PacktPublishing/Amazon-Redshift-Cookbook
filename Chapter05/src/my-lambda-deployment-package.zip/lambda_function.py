#!/usr/bin/python
# -*- coding: utf-8 -*-

import psycopg2
import json
import uuid
from urllib.parse import unquote_plus

def lambda_handler(event, context):
  
  bucket = unquote_plus(event['Records'][0]['s3']['bucket']['name'])
  key = unquote_plus(event['Records'][0]['s3']['object']['key'])
  
  print ("copying:"+bucket+key)

  db_database = "[database]"
  db_user = "[user]" 
  db_password = "[password]"
  db_port = "[port]"
  db_host = "[host]"
  iam_role = "'arn:aws:iam::[Your-AWS_Account_Id]:role/[Your-Redshift-Role]"
  
  conn = psycopg2.connect("dbname=" + db_database
                         + " user=" + db_user
                         + " password=" + db_password
                         + " port=" + db_port
                         + " host=" + db_host)

  conn.autocommit = True
  cur = conn.cursor()
  cur.execute("create table if not exists stg_part (  NAME VARCHAR(55),  MFGR   VARCHAR(25),  BRAND  VARCHAR(10),  TYPE VARCHAR(25),  SIZE   INTEGER,  CONTAINER     VARCHAR(10),  RETAILPRICE   DECIMAL(18,4),  COMMENT VARCHAR(23)) ")
  cur.execute("COPY stg_part FROM 's3://"+ bucket + "/" + key + "' iam_role '"+ iam_role + "' csv gzip")
  cur.close()
  conn.close()
  
